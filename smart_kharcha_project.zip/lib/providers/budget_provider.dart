import 'package:flutter/material.dart';

class Category {
  String name;
  double budget;
  double spent;

  Category({required this.name, required this.budget, this.spent = 0});

  double get remaining => budget - spent;
}

class BudgetProvider with ChangeNotifier {
  List<Category> categories = [
    Category(name: "Vegetables", budget: 5000),
    Category(name: "Chicken", budget: 5000),
    Category(name: "Meat", budget: 7000),
    Category(name: "Groceries", budget: 10000),
  ];

  void addExpense(String categoryName, double amount) {
    final category = categories.firstWhere((c) => c.name == categoryName);
    category.spent += amount;
    notifyListeners();
  }

  double totalRemaining() {
    return categories.fold(0, (sum, c) => sum + c.remaining);
  }
}
