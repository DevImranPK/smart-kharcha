import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/budget_provider.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(SmartKharchaApp());
}

class SmartKharchaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => BudgetProvider(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Smart Kharcha',
        theme: ThemeData(primarySwatch: Colors.green),
        home: HomeScreen(),
      ),
    );
  }
}
